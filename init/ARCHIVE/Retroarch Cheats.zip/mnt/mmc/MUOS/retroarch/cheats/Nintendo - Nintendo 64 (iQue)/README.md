# Gents: Nintendo - Nintendo 64 (iQue) Cheats for RetroArch

All Cheats created by Gent of [Emucheats](https://emucheats.emulation64.com/)
You can also get in touch via Discord and the [Emucheats Discord Channel](https://discord.gg/aEEtyj6)

All Cheats were created using Project64 Legacy & RetroArch Mupen64Plus-Next Core. Any support missing is due to issues with the emulator and will be catered for once they are working.