import sys
import pytest
from sdl2 import ext as sdl2ext

# NOTE: Deprecated, so I'm not writing tests for it


class TestExtUIFactory(object):
    __tags__ = ["sdl", "sdl2ext"]

    @pytest.mark.skip("not implemented")
    def test_init(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_create_button(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_create_checkbutton(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_create_text_entry(self):
        pass


class TestExtUIProcessor(object):
    __tags__ = ["sdl", "sdl2ext"]

    @pytest.mark.skip("not implemented")
    def test_init(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_activate(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_deactivate(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_dispatch(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_mousedown(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_mouseup(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_mousemotion(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_passevent(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_process(self):
        pass

    @pytest.mark.skip("not implemented")
    def test_textinput(self):
        pass
